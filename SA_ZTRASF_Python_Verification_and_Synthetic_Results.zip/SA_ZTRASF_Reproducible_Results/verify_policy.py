#!/usr/bin/env python3
"""SA-ZTRASF deterministic policy verification. Standard library only."""
import csv, itertools, json
from pathlib import Path
OUT = Path(__file__).resolve().parent

def authorise(I, S, P, O):
    inputs = (I, S, P, O)
    if any(type(x) is not int or x not in (0, 1) for x in inputs):
        raise ValueError("All four policy conditions must be binary integers (0 or 1)")
    return I & S & P & O

def write_csv(name, rows, columns):
    with (OUT / name).open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)

truth = []
for bits in itertools.product((0, 1), repeat=4):
    expected = int(all(bits))
    actual = authorise(*bits)
    truth.append(dict(zip(("I","S","P","O"), bits), expected_A=expected,
                      computed_A=actual, passed=int(actual == expected)))

scenarios = [
    ("Legitimate authorised supervisory command", 1,1,1,1),
    ("Credential compromise with failed device verification", 0,1,1,1),
    ("Authentication-token replay with invalid session binding", 1,0,1,1),
    ("Session hijacking with failed integrity verification", 1,0,1,1),
    ("Privilege misuse beyond approved task scope", 1,1,0,1),
    ("Command prohibited under current operational state", 1,1,1,0),
    ("Operational-state information unavailable or unreliable", 1,1,1,0),
]
scenario_rows = []
for name, I, S, P, O in scenarios:
    actual = authorise(I,S,P,O)
    expected = I*S*P*O
    scenario_rows.append(dict(scenario=name,I=I,S=S,P=P,O=O,
                              expected_A=expected,computed_A=actual,passed=int(actual==expected)))

invalid = [
    ("nonbinary integer", (2,1,1,1)),
    ("negative integer", (-1,1,1,1)),
    ("string value", ("1",1,1,1)),
    ("missing value", (None,1,1,1)),
]
invalid_rows = []
for name, inputs in invalid:
    try:
        authorise(*inputs)
        passed = 0
        outcome = "incorrectly accepted"
    except ValueError:
        passed = 1
        outcome = "ValueError raised"
    invalid_rows.append(dict(case=name,inputs=repr(inputs),expected="ValueError",
                             observed=outcome,passed=passed))

write_csv("truth_table_results.csv",truth,["I","S","P","O","expected_A","computed_A","passed"])
write_csv("scenario_verification.csv",scenario_rows,["scenario","I","S","P","O","expected_A","computed_A","passed"])
write_csv("invalid_input_verification.csv",invalid_rows,["case","inputs","expected","observed","passed"])
summary = {
    "boolean_checks": len(truth), "boolean_passed": sum(r["passed"] for r in truth),
    "scenario_checks": len(scenario_rows), "scenario_passed": sum(r["passed"] for r in scenario_rows),
    "invalid_input_checks": len(invalid_rows), "invalid_input_passed": sum(r["passed"] for r in invalid_rows),
}
summary["total_checks"] = sum(summary[k] for k in ("boolean_checks","scenario_checks","invalid_input_checks"))
summary["total_passed"] = sum(summary[k] for k in ("boolean_passed","scenario_passed","invalid_input_passed"))
(OUT / "verification_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
assert summary["total_checks"] == summary["total_passed"] == 27
print("Policy verification:", summary["total_passed"], "/", summary["total_checks"], "passed")
